﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CitationForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CitationForm))
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LinkLabel3 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel4 = New System.Windows.Forms.LinkLabel()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LinkLabel5 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel6 = New System.Windows.Forms.LinkLabel()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.ComboBox8 = New System.Windows.Forms.ComboBox()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.LinkLabel7 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel8 = New System.Windows.Forms.LinkLabel()
        Me.ComboBox9 = New System.Windows.Forms.ComboBox()
        Me.ComboBox10 = New System.Windows.Forms.ComboBox()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.LinkLabel9 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel10 = New System.Windows.Forms.LinkLabel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.idinfo_citation_citeinfo_pubdate_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning = New System.Windows.Forms.PictureBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_citation_citeinfo_pubinfo_____warning = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_pubdate_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_pubdate_____today = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.idinfo_citation_citeinfo_pubdate = New System.Windows.Forms.TextBox()
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_pubinfo_publish = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_pubinfo_pubplace = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help = New System.Windows.Forms.LinkLabel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.idinfo_citation_citeinfo_title_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_citation_citeinfo_origin_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_citation_citeinfo_title_____default = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.idinfo_citation_citeinfo_title_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_origin_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_origin_____default = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_title = New System.Windows.Forms.TextBox()
        Me.idinfo_citation_citeinfo_origin = New System.Windows.Forms.TextBox()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning = New System.Windows.Forms.PictureBox()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv = New System.Windows.Forms.TextBox()
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help = New System.Windows.Forms.LinkLabel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.LinkLabel11 = New System.Windows.Forms.LinkLabel()
        Me.ComboBox11 = New System.Windows.Forms.ComboBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.LinkLabel12 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel13 = New System.Windows.Forms.LinkLabel()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.LinkLabel14 = New System.Windows.Forms.LinkLabel()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me._____warning = New System.Windows.Forms.PictureBox()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnCloseDiscard = New System.Windows.Forms.Button()
        Me.btnCloseSave = New System.Windows.Forms.Button()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.LinkLabel15 = New System.Windows.Forms.LinkLabel()
        Me.btnEdit_lworkcit = New System.Windows.Forms.Button()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.Panel22.SuspendLayout()
        CType(Me.idinfo_citation_citeinfo_pubdate_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_citation_citeinfo_pubinfo_publish_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_citation_citeinfo_pubinfo_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.idinfo_citation_citeinfo_title_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_citation_citeinfo_origin_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel12.SuspendLayout()
        CType(Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel6.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me._____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel28.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel29.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.Panel8.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox4, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox2, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox3, 0, 1)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 1)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(881, 423)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.Panel8)
        Me.GroupBox2.Controls.Add(Me.Panel2)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Black
        Me.GroupBox2.Location = New System.Drawing.Point(443, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(435, 371)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel2.Controls.Add(Me.ComboBox1)
        Me.Panel2.Controls.Add(Me.ComboBox2)
        Me.Panel2.Controls.Add(Me.Button3)
        Me.Panel2.Controls.Add(Me.Button4)
        Me.Panel2.Controls.Add(Me.Button5)
        Me.Panel2.Controls.Add(Me.Button6)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.LinkLabel1)
        Me.Panel2.Controls.Add(Me.LinkLabel2)
        Me.Panel2.Controls.Add(Me.ComboBox3)
        Me.Panel2.Controls.Add(Me.ComboBox4)
        Me.Panel2.Controls.Add(Me.Button7)
        Me.Panel2.Controls.Add(Me.Button8)
        Me.Panel2.Controls.Add(Me.Button9)
        Me.Panel2.Controls.Add(Me.Button10)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.LinkLabel3)
        Me.Panel2.Controls.Add(Me.LinkLabel4)
        Me.Panel2.Controls.Add(Me.ComboBox5)
        Me.Panel2.Controls.Add(Me.ComboBox6)
        Me.Panel2.Controls.Add(Me.Button11)
        Me.Panel2.Controls.Add(Me.Button12)
        Me.Panel2.Controls.Add(Me.Button13)
        Me.Panel2.Controls.Add(Me.Button14)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.LinkLabel5)
        Me.Panel2.Controls.Add(Me.LinkLabel6)
        Me.Panel2.Controls.Add(Me.ComboBox7)
        Me.Panel2.Controls.Add(Me.ComboBox8)
        Me.Panel2.Controls.Add(Me.Button15)
        Me.Panel2.Controls.Add(Me.Button16)
        Me.Panel2.Controls.Add(Me.Button17)
        Me.Panel2.Controls.Add(Me.Button18)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.LinkLabel7)
        Me.Panel2.Controls.Add(Me.LinkLabel8)
        Me.Panel2.Controls.Add(Me.ComboBox9)
        Me.Panel2.Controls.Add(Me.ComboBox10)
        Me.Panel2.Controls.Add(Me.Button19)
        Me.Panel2.Controls.Add(Me.Button20)
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Controls.Add(Me.Button21)
        Me.Panel2.Controls.Add(Me.Button22)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.LinkLabel9)
        Me.Panel2.Controls.Add(Me.LinkLabel10)
        Me.Panel2.Location = New System.Drawing.Point(6, 18)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(423, 306)
        Me.Panel2.TabIndex = 23
        '
        'ComboBox1
        '
        Me.ComboBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.ComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(120, 260)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(228, 21)
        Me.ComboBox1.TabIndex = 129
        '
        'ComboBox2
        '
        Me.ComboBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.ComboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(120, 233)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(228, 21)
        Me.ComboBox2.TabIndex = 128
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button3.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(354, 258)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(33, 23)
        Me.Button3.TabIndex = 127
        Me.Button3.Text = "D"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button4.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(354, 231)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(33, 23)
        Me.Button4.TabIndex = 126
        Me.Button4.Text = "D"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button5.AutoSize = True
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Image = CType(resources.GetObject("Button5.Image"), System.Drawing.Image)
        Me.Button5.Location = New System.Drawing.Point(389, 257)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(25, 24)
        Me.Button5.TabIndex = 125
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button6.AutoSize = True
        Me.Button6.FlatAppearance.BorderSize = 0
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Image = CType(resources.GetObject("Button6.Image"), System.Drawing.Image)
        Me.Button6.Location = New System.Drawing.Point(389, 230)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(25, 24)
        Me.Button6.TabIndex = 124
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(3, 263)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(19, 13)
        Me.Label1.TabIndex = 123
        Me.Label1.Text = "**"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(3, 236)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(19, 13)
        Me.Label2.TabIndex = 122
        Me.Label2.Text = "**"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(19, 235)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(56, 13)
        Me.LinkLabel1.TabIndex = 120
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Linkage 9:"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel2.Location = New System.Drawing.Point(19, 263)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(62, 13)
        Me.LinkLabel2.TabIndex = 121
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Linkage 10:"
        '
        'ComboBox3
        '
        Me.ComboBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.ComboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(120, 206)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(228, 21)
        Me.ComboBox3.TabIndex = 119
        '
        'ComboBox4
        '
        Me.ComboBox4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.ComboBox4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(120, 179)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(228, 21)
        Me.ComboBox4.TabIndex = 118
        '
        'Button7
        '
        Me.Button7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button7.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button7.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(354, 204)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(33, 23)
        Me.Button7.TabIndex = 117
        Me.Button7.Text = "D"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button8.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button8.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(354, 177)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(33, 23)
        Me.Button8.TabIndex = 116
        Me.Button8.Text = "D"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button9.AutoSize = True
        Me.Button9.FlatAppearance.BorderSize = 0
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Image = CType(resources.GetObject("Button9.Image"), System.Drawing.Image)
        Me.Button9.Location = New System.Drawing.Point(389, 203)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(25, 24)
        Me.Button9.TabIndex = 115
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button10.AutoSize = True
        Me.Button10.FlatAppearance.BorderSize = 0
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Image = CType(resources.GetObject("Button10.Image"), System.Drawing.Image)
        Me.Button10.Location = New System.Drawing.Point(389, 176)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(25, 24)
        Me.Button10.TabIndex = 114
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(3, 209)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(19, 13)
        Me.Label3.TabIndex = 113
        Me.Label3.Text = "**"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(3, 182)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(19, 13)
        Me.Label4.TabIndex = 112
        Me.Label4.Text = "**"
        '
        'LinkLabel3
        '
        Me.LinkLabel3.AutoSize = True
        Me.LinkLabel3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel3.Location = New System.Drawing.Point(19, 181)
        Me.LinkLabel3.Name = "LinkLabel3"
        Me.LinkLabel3.Size = New System.Drawing.Size(56, 13)
        Me.LinkLabel3.TabIndex = 110
        Me.LinkLabel3.TabStop = True
        Me.LinkLabel3.Text = "Linkage 7:"
        '
        'LinkLabel4
        '
        Me.LinkLabel4.AutoSize = True
        Me.LinkLabel4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel4.Location = New System.Drawing.Point(19, 209)
        Me.LinkLabel4.Name = "LinkLabel4"
        Me.LinkLabel4.Size = New System.Drawing.Size(56, 13)
        Me.LinkLabel4.TabIndex = 111
        Me.LinkLabel4.TabStop = True
        Me.LinkLabel4.Text = "Linkage 8:"
        '
        'ComboBox5
        '
        Me.ComboBox5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.ComboBox5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(120, 152)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(228, 21)
        Me.ComboBox5.TabIndex = 109
        '
        'ComboBox6
        '
        Me.ComboBox6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.ComboBox6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Location = New System.Drawing.Point(120, 125)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(228, 21)
        Me.ComboBox6.TabIndex = 108
        '
        'Button11
        '
        Me.Button11.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button11.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button11.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(354, 150)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(33, 23)
        Me.Button11.TabIndex = 107
        Me.Button11.Text = "D"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button12.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button12.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.Location = New System.Drawing.Point(354, 123)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(33, 23)
        Me.Button12.TabIndex = 106
        Me.Button12.Text = "D"
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button13.AutoSize = True
        Me.Button13.FlatAppearance.BorderSize = 0
        Me.Button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button13.Image = CType(resources.GetObject("Button13.Image"), System.Drawing.Image)
        Me.Button13.Location = New System.Drawing.Point(389, 149)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(25, 24)
        Me.Button13.TabIndex = 105
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button14.AutoSize = True
        Me.Button14.FlatAppearance.BorderSize = 0
        Me.Button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button14.Image = CType(resources.GetObject("Button14.Image"), System.Drawing.Image)
        Me.Button14.Location = New System.Drawing.Point(389, 122)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(25, 24)
        Me.Button14.TabIndex = 104
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(3, 155)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(19, 13)
        Me.Label5.TabIndex = 103
        Me.Label5.Text = "**"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(3, 128)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(19, 13)
        Me.Label6.TabIndex = 102
        Me.Label6.Text = "**"
        '
        'LinkLabel5
        '
        Me.LinkLabel5.AutoSize = True
        Me.LinkLabel5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel5.Location = New System.Drawing.Point(19, 127)
        Me.LinkLabel5.Name = "LinkLabel5"
        Me.LinkLabel5.Size = New System.Drawing.Size(56, 13)
        Me.LinkLabel5.TabIndex = 100
        Me.LinkLabel5.TabStop = True
        Me.LinkLabel5.Text = "Linkage 5:"
        '
        'LinkLabel6
        '
        Me.LinkLabel6.AutoSize = True
        Me.LinkLabel6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel6.Location = New System.Drawing.Point(19, 155)
        Me.LinkLabel6.Name = "LinkLabel6"
        Me.LinkLabel6.Size = New System.Drawing.Size(56, 13)
        Me.LinkLabel6.TabIndex = 101
        Me.LinkLabel6.TabStop = True
        Me.LinkLabel6.Text = "Linkage 6:"
        '
        'ComboBox7
        '
        Me.ComboBox7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.ComboBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Location = New System.Drawing.Point(120, 98)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(228, 21)
        Me.ComboBox7.TabIndex = 99
        '
        'ComboBox8
        '
        Me.ComboBox8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.ComboBox8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox8.FormattingEnabled = True
        Me.ComboBox8.Location = New System.Drawing.Point(120, 71)
        Me.ComboBox8.Name = "ComboBox8"
        Me.ComboBox8.Size = New System.Drawing.Size(228, 21)
        Me.ComboBox8.TabIndex = 98
        '
        'Button15
        '
        Me.Button15.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button15.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button15.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.Location = New System.Drawing.Point(354, 96)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(33, 23)
        Me.Button15.TabIndex = 97
        Me.Button15.Text = "D"
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button16.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button16.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.Location = New System.Drawing.Point(354, 69)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(33, 23)
        Me.Button16.TabIndex = 96
        Me.Button16.Text = "D"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'Button17
        '
        Me.Button17.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button17.AutoSize = True
        Me.Button17.FlatAppearance.BorderSize = 0
        Me.Button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button17.Image = CType(resources.GetObject("Button17.Image"), System.Drawing.Image)
        Me.Button17.Location = New System.Drawing.Point(389, 95)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(25, 24)
        Me.Button17.TabIndex = 95
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button18.AutoSize = True
        Me.Button18.FlatAppearance.BorderSize = 0
        Me.Button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button18.Image = CType(resources.GetObject("Button18.Image"), System.Drawing.Image)
        Me.Button18.Location = New System.Drawing.Point(389, 68)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(25, 24)
        Me.Button18.TabIndex = 94
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(3, 101)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(19, 13)
        Me.Label12.TabIndex = 93
        Me.Label12.Text = "**"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(3, 74)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(19, 13)
        Me.Label13.TabIndex = 92
        Me.Label13.Text = "**"
        '
        'LinkLabel7
        '
        Me.LinkLabel7.AutoSize = True
        Me.LinkLabel7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel7.Location = New System.Drawing.Point(19, 73)
        Me.LinkLabel7.Name = "LinkLabel7"
        Me.LinkLabel7.Size = New System.Drawing.Size(56, 13)
        Me.LinkLabel7.TabIndex = 90
        Me.LinkLabel7.TabStop = True
        Me.LinkLabel7.Text = "Linkage 3:"
        '
        'LinkLabel8
        '
        Me.LinkLabel8.AutoSize = True
        Me.LinkLabel8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel8.Location = New System.Drawing.Point(19, 101)
        Me.LinkLabel8.Name = "LinkLabel8"
        Me.LinkLabel8.Size = New System.Drawing.Size(56, 13)
        Me.LinkLabel8.TabIndex = 91
        Me.LinkLabel8.TabStop = True
        Me.LinkLabel8.Text = "Linkage 4:"
        '
        'ComboBox9
        '
        Me.ComboBox9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.ComboBox9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Location = New System.Drawing.Point(120, 44)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(228, 21)
        Me.ComboBox9.TabIndex = 39
        '
        'ComboBox10
        '
        Me.ComboBox10.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.ComboBox10.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox10.FormattingEnabled = True
        Me.ComboBox10.Location = New System.Drawing.Point(120, 17)
        Me.ComboBox10.Name = "ComboBox10"
        Me.ComboBox10.Size = New System.Drawing.Size(228, 21)
        Me.ComboBox10.TabIndex = 38
        '
        'Button19
        '
        Me.Button19.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button19.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button19.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button19.Location = New System.Drawing.Point(354, 44)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(33, 23)
        Me.Button19.TabIndex = 37
        Me.Button19.Text = "D"
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button20.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button20.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button20.Location = New System.Drawing.Point(354, 17)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(33, 23)
        Me.Button20.TabIndex = 36
        Me.Button20.Text = "D"
        Me.Button20.UseVisualStyleBackColor = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.PictureBox2.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.PictureBox2.Location = New System.Drawing.Point(92, -1)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(13, 14)
        Me.PictureBox2.TabIndex = 35
        Me.PictureBox2.TabStop = False
        Me.PictureBox2.Visible = False
        '
        'Button21
        '
        Me.Button21.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button21.AutoSize = True
        Me.Button21.FlatAppearance.BorderSize = 0
        Me.Button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button21.Image = CType(resources.GetObject("Button21.Image"), System.Drawing.Image)
        Me.Button21.Location = New System.Drawing.Point(389, 42)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(25, 24)
        Me.Button21.TabIndex = 26
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button22.AutoSize = True
        Me.Button22.FlatAppearance.BorderSize = 0
        Me.Button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button22.Image = CType(resources.GetObject("Button22.Image"), System.Drawing.Image)
        Me.Button22.Location = New System.Drawing.Point(389, 16)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(25, 24)
        Me.Button22.TabIndex = 25
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(3, 47)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(19, 13)
        Me.Label14.TabIndex = 24
        Me.Label14.Text = "**"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(3, 20)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(19, 13)
        Me.Label15.TabIndex = 22
        Me.Label15.Text = "**"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(7, -3)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(89, 13)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "Online Linkage"
        '
        'LinkLabel9
        '
        Me.LinkLabel9.AutoSize = True
        Me.LinkLabel9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel9.Location = New System.Drawing.Point(19, 19)
        Me.LinkLabel9.Name = "LinkLabel9"
        Me.LinkLabel9.Size = New System.Drawing.Size(86, 13)
        Me.LinkLabel9.TabIndex = 0
        Me.LinkLabel9.TabStop = True
        Me.LinkLabel9.Text = "Primary Linkage:"
        '
        'LinkLabel10
        '
        Me.LinkLabel10.AutoSize = True
        Me.LinkLabel10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel10.Location = New System.Drawing.Point(19, 47)
        Me.LinkLabel10.Name = "LinkLabel10"
        Me.LinkLabel10.Size = New System.Drawing.Size(101, 13)
        Me.LinkLabel10.TabIndex = 1
        Me.LinkLabel10.TabStop = True
        Me.LinkLabel10.Text = "Secondary Linkage:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.Panel6)
        Me.GroupBox1.Controls.Add(Me.Panel4)
        Me.GroupBox1.Controls.Add(Me.Panel3)
        Me.GroupBox1.Controls.Add(Me.Panel12)
        Me.GroupBox1.Controls.Add(Me.Panel22)
        Me.GroupBox1.Controls.Add(Me.Panel1)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.GroupBox1.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(434, 371)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'Panel22
        '
        Me.Panel22.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel22.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubdate_____warning)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning)
        Me.Panel22.Controls.Add(Me.Label9)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_publish_____warning)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_____warning)
        Me.Panel22.Controls.Add(Me.Button2)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubdate_____help)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubdate_____today)
        Me.Panel22.Controls.Add(Me.Label11)
        Me.Panel22.Controls.Add(Me.Label10)
        Me.Panel22.Controls.Add(Me.Label25)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubdate)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_publish_____help)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_publish)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_pubplace)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help)
        Me.Panel22.Location = New System.Drawing.Point(6, 121)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(422, 70)
        Me.Panel22.TabIndex = 0
        '
        'idinfo_citation_citeinfo_pubdate_____warning
        '
        Me.idinfo_citation_citeinfo_pubdate_____warning.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_pubdate_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubdate_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubdate_____warning.Location = New System.Drawing.Point(289, 46)
        Me.idinfo_citation_citeinfo_pubdate_____warning.Name = "idinfo_citation_citeinfo_pubdate_____warning"
        Me.idinfo_citation_citeinfo_pubdate_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_pubdate_____warning.TabIndex = 35
        Me.idinfo_citation_citeinfo_pubdate_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_pubdate_____warning.Visible = False
        '
        'idinfo_citation_citeinfo_pubinfo_pubplace_____warning
        '
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.Location = New System.Drawing.Point(79, 44)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.Name = "idinfo_citation_citeinfo_pubinfo_pubplace_____warning"
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.TabIndex = 34
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(3, 17)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(13, 13)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "*"
        '
        'idinfo_citation_citeinfo_pubinfo_publish_____warning
        '
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.Location = New System.Drawing.Point(79, 17)
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.Name = "idinfo_citation_citeinfo_pubinfo_publish_____warning"
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.TabIndex = 33
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.Visible = False
        '
        'idinfo_citation_citeinfo_pubinfo_____warning
        '
        Me.idinfo_citation_citeinfo_pubinfo_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubinfo_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubinfo_____warning.Location = New System.Drawing.Point(66, -1)
        Me.idinfo_citation_citeinfo_pubinfo_____warning.Name = "idinfo_citation_citeinfo_pubinfo_____warning"
        Me.idinfo_citation_citeinfo_pubinfo_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_pubinfo_____warning.TabIndex = 32
        Me.idinfo_citation_citeinfo_pubinfo_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_pubinfo_____warning.Visible = False
        '
        'Button2
        '
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button2.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(378, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(33, 23)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "D"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_pubdate_____help
        '
        Me.idinfo_citation_citeinfo_pubdate_____help.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_pubdate_____help.AutoSize = True
        Me.idinfo_citation_citeinfo_pubdate_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubdate_____help.Location = New System.Drawing.Point(262, 45)
        Me.idinfo_citation_citeinfo_pubdate_____help.Name = "idinfo_citation_citeinfo_pubdate_____help"
        Me.idinfo_citation_citeinfo_pubdate_____help.Size = New System.Drawing.Size(34, 13)
        Me.idinfo_citation_citeinfo_pubdate_____help.TabIndex = 9
        Me.idinfo_citation_citeinfo_pubdate_____help.TabStop = True
        Me.idinfo_citation_citeinfo_pubdate_____help.Text = "Date:"
        '
        'idinfo_citation_citeinfo_pubdate_____today
        '
        Me.idinfo_citation_citeinfo_pubdate_____today.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_pubdate_____today.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_pubdate_____today.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubdate_____today.Location = New System.Drawing.Point(368, 41)
        Me.idinfo_citation_citeinfo_pubdate_____today.Name = "idinfo_citation_citeinfo_pubdate_____today"
        Me.idinfo_citation_citeinfo_pubdate_____today.Size = New System.Drawing.Size(43, 23)
        Me.idinfo_citation_citeinfo_pubdate_____today.TabIndex = 11
        Me.idinfo_citation_citeinfo_pubdate_____today.Text = "today"
        Me.idinfo_citation_citeinfo_pubdate_____today.UseVisualStyleBackColor = False
        '
        'Label11
        '
        Me.Label11.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(251, 46)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(13, 13)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "*"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(3, 44)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(13, 13)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "*"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(7, -3)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(59, 13)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "Publisher"
        '
        'idinfo_citation_citeinfo_pubdate
        '
        Me.idinfo_citation_citeinfo_pubdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_pubdate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubdate.Location = New System.Drawing.Point(302, 41)
        Me.idinfo_citation_citeinfo_pubdate.Name = "idinfo_citation_citeinfo_pubdate"
        Me.idinfo_citation_citeinfo_pubdate.Size = New System.Drawing.Size(62, 21)
        Me.idinfo_citation_citeinfo_pubdate.TabIndex = 10
        Me.idinfo_citation_citeinfo_pubdate.Text = "YYYYMMDD"
        '
        'idinfo_citation_citeinfo_pubinfo_publish_____help
        '
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.AutoSize = True
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.Location = New System.Drawing.Point(15, 17)
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.Name = "idinfo_citation_citeinfo_pubinfo_publish_____help"
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.Size = New System.Drawing.Size(71, 13)
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.TabIndex = 2
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.TabStop = True
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.Text = "Published by:"
        '
        'idinfo_citation_citeinfo_pubinfo_publish
        '
        Me.idinfo_citation_citeinfo_pubinfo_publish.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_pubinfo_publish.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.idinfo_citation_citeinfo_pubinfo_publish.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_pubinfo_publish.DropDownWidth = 600
        Me.idinfo_citation_citeinfo_pubinfo_publish.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubinfo_publish.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_pubinfo_publish.Location = New System.Drawing.Point(98, 14)
        Me.idinfo_citation_citeinfo_pubinfo_publish.Name = "idinfo_citation_citeinfo_pubinfo_publish"
        Me.idinfo_citation_citeinfo_pubinfo_publish.Size = New System.Drawing.Size(266, 21)
        Me.idinfo_citation_citeinfo_pubinfo_publish.TabIndex = 3
        '
        'idinfo_citation_citeinfo_pubinfo_pubplace
        '
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.Location = New System.Drawing.Point(98, 41)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.Name = "idinfo_citation_citeinfo_pubinfo_pubplace"
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.Size = New System.Drawing.Size(147, 21)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.TabIndex = 7
        '
        'idinfo_citation_citeinfo_pubinfo_pubplace_____help
        '
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.AutoSize = True
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.Location = New System.Drawing.Point(15, 44)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.Name = "idinfo_citation_citeinfo_pubinfo_pubplace_____help"
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.Size = New System.Drawing.Size(69, 13)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.TabIndex = 6
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.TabStop = True
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.Text = "Published at:"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_title_____warning)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_origin_____warning)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_title_____default)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_title_____help)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_origin_____help)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_origin_____default)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_title)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_origin)
        Me.Panel1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(6, 18)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(422, 54)
        Me.Panel1.TabIndex = 0
        '
        'idinfo_citation_citeinfo_title_____warning
        '
        Me.idinfo_citation_citeinfo_title_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_title_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_title_____warning.Location = New System.Drawing.Point(53, 37)
        Me.idinfo_citation_citeinfo_title_____warning.Name = "idinfo_citation_citeinfo_title_____warning"
        Me.idinfo_citation_citeinfo_title_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_title_____warning.TabIndex = 35
        Me.idinfo_citation_citeinfo_title_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_title_____warning.Visible = False
        '
        'idinfo_citation_citeinfo_origin_____warning
        '
        Me.idinfo_citation_citeinfo_origin_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_origin_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_origin_____warning.Location = New System.Drawing.Point(53, 9)
        Me.idinfo_citation_citeinfo_origin_____warning.Name = "idinfo_citation_citeinfo_origin_____warning"
        Me.idinfo_citation_citeinfo_origin_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_origin_____warning.TabIndex = 34
        Me.idinfo_citation_citeinfo_origin_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_origin_____warning.Visible = False
        '
        'idinfo_citation_citeinfo_title_____default
        '
        Me.idinfo_citation_citeinfo_title_____default.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_title_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_title_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_title_____default.Location = New System.Drawing.Point(378, 28)
        Me.idinfo_citation_citeinfo_title_____default.Name = "idinfo_citation_citeinfo_title_____default"
        Me.idinfo_citation_citeinfo_title_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_title_____default.TabIndex = 7
        Me.idinfo_citation_citeinfo_title_____default.Text = "D"
        Me.idinfo_citation_citeinfo_title_____default.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(11, 37)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(13, 13)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "*"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(11, 9)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(13, 13)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "*"
        '
        'idinfo_citation_citeinfo_title_____help
        '
        Me.idinfo_citation_citeinfo_title_____help.AutoSize = True
        Me.idinfo_citation_citeinfo_title_____help.Location = New System.Drawing.Point(22, 36)
        Me.idinfo_citation_citeinfo_title_____help.Name = "idinfo_citation_citeinfo_title_____help"
        Me.idinfo_citation_citeinfo_title_____help.Size = New System.Drawing.Size(31, 13)
        Me.idinfo_citation_citeinfo_title_____help.TabIndex = 5
        Me.idinfo_citation_citeinfo_title_____help.TabStop = True
        Me.idinfo_citation_citeinfo_title_____help.Text = "Title:"
        '
        'idinfo_citation_citeinfo_origin_____help
        '
        Me.idinfo_citation_citeinfo_origin_____help.AutoSize = True
        Me.idinfo_citation_citeinfo_origin_____help.Location = New System.Drawing.Point(21, 8)
        Me.idinfo_citation_citeinfo_origin_____help.Name = "idinfo_citation_citeinfo_origin_____help"
        Me.idinfo_citation_citeinfo_origin_____help.Size = New System.Drawing.Size(39, 13)
        Me.idinfo_citation_citeinfo_origin_____help.TabIndex = 1
        Me.idinfo_citation_citeinfo_origin_____help.TabStop = True
        Me.idinfo_citation_citeinfo_origin_____help.Text = "Origin:"
        '
        'idinfo_citation_citeinfo_origin_____default
        '
        Me.idinfo_citation_citeinfo_origin_____default.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_origin_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_origin_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_origin_____default.Location = New System.Drawing.Point(378, 2)
        Me.idinfo_citation_citeinfo_origin_____default.Name = "idinfo_citation_citeinfo_origin_____default"
        Me.idinfo_citation_citeinfo_origin_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_origin_____default.TabIndex = 3
        Me.idinfo_citation_citeinfo_origin_____default.Text = "D"
        Me.idinfo_citation_citeinfo_origin_____default.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_title
        '
        Me.idinfo_citation_citeinfo_title.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_title.Location = New System.Drawing.Point(69, 30)
        Me.idinfo_citation_citeinfo_title.Name = "idinfo_citation_citeinfo_title"
        Me.idinfo_citation_citeinfo_title.Size = New System.Drawing.Size(295, 21)
        Me.idinfo_citation_citeinfo_title.TabIndex = 6
        '
        'idinfo_citation_citeinfo_origin
        '
        Me.idinfo_citation_citeinfo_origin.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_origin.Location = New System.Drawing.Point(69, 4)
        Me.idinfo_citation_citeinfo_origin.Name = "idinfo_citation_citeinfo_origin"
        Me.idinfo_citation_citeinfo_origin.Size = New System.Drawing.Size(295, 21)
        Me.idinfo_citation_citeinfo_origin.TabIndex = 2
        '
        'Panel12
        '
        Me.Panel12.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel12.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel12.Controls.Add(Me.Button1)
        Me.Panel12.Controls.Add(Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning)
        Me.Panel12.Controls.Add(Me.Label59)
        Me.Panel12.Controls.Add(Me.dataqual_posacc_vertacc_qvertpa_vertaccv)
        Me.Panel12.Controls.Add(Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help)
        Me.Panel12.Location = New System.Drawing.Point(6, 78)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(422, 34)
        Me.Panel12.TabIndex = 25
        '
        'dataqual_posacc_vertacc_qvertpa_vertaccv_____warning
        '
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.Location = New System.Drawing.Point(55, 12)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.Name = "dataqual_posacc_vertacc_qvertpa_vertaccv_____warning"
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.TabIndex = 48
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.TabStop = False
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.Visible = False
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.ForeColor = System.Drawing.Color.Black
        Me.Label59.Location = New System.Drawing.Point(5, 12)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(19, 13)
        Me.Label59.TabIndex = 27
        Me.Label59.Text = "**"
        '
        'dataqual_posacc_vertacc_qvertpa_vertaccv
        '
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv.Location = New System.Drawing.Point(69, 6)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv.Name = "dataqual_posacc_vertacc_qvertpa_vertaccv"
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv.Size = New System.Drawing.Size(295, 21)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv.TabIndex = 1
        '
        'dataqual_posacc_vertacc_qvertpa_vertaccv_____help
        '
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.AutoSize = True
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.Location = New System.Drawing.Point(22, 10)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.Name = "dataqual_posacc_vertacc_qvertpa_vertaccv_____help"
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.Size = New System.Drawing.Size(43, 13)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.TabIndex = 0
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.TabStop = True
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.Text = "Edition:"
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button1.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(378, 5)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(33, 23)
        Me.Button1.TabIndex = 49
        Me.Button1.Text = "D"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel3.Controls.Add(Me.ComboBox11)
        Me.Panel3.Controls.Add(Me.Button23)
        Me.Panel3.Controls.Add(Me.PictureBox1)
        Me.Panel3.Controls.Add(Me.Label17)
        Me.Panel3.Controls.Add(Me.LinkLabel11)
        Me.Panel3.Location = New System.Drawing.Point(6, 197)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(422, 34)
        Me.Panel3.TabIndex = 26
        '
        'Button23
        '
        Me.Button23.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button23.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button23.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button23.Location = New System.Drawing.Point(378, 5)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(33, 23)
        Me.Button23.TabIndex = 49
        Me.Button23.Text = "D"
        Me.Button23.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.PictureBox1.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.PictureBox1.Location = New System.Drawing.Point(206, 11)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(13, 14)
        Me.PictureBox1.TabIndex = 48
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Visible = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(5, 12)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(19, 13)
        Me.Label17.TabIndex = 27
        Me.Label17.Text = "**"
        '
        'LinkLabel11
        '
        Me.LinkLabel11.AutoSize = True
        Me.LinkLabel11.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel11.Location = New System.Drawing.Point(22, 10)
        Me.LinkLabel11.Name = "LinkLabel11"
        Me.LinkLabel11.Size = New System.Drawing.Size(188, 13)
        Me.LinkLabel11.TabIndex = 0
        Me.LinkLabel11.TabStop = True
        Me.LinkLabel11.Text = "Geospatial Data Presentation Format:"
        '
        'ComboBox11
        '
        Me.ComboBox11.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox11.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.ComboBox11.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox11.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Location = New System.Drawing.Point(221, 7)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(143, 21)
        Me.ComboBox11.TabIndex = 50
        '
        'Panel4
        '
        Me.Panel4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Controls.Add(Me.Label18)
        Me.Panel4.Location = New System.Drawing.Point(6, 239)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(422, 85)
        Me.Panel4.TabIndex = 27
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(7, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(113, 13)
        Me.Label18.TabIndex = 2
        Me.Label18.Text = "Series Information"
        '
        'Panel5
        '
        Me.Panel5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel5.Controls.Add(Me.PictureBox3)
        Me.Panel5.Controls.Add(Me.PictureBox4)
        Me.Panel5.Controls.Add(Me.Button24)
        Me.Panel5.Controls.Add(Me.Label19)
        Me.Panel5.Controls.Add(Me.Label20)
        Me.Panel5.Controls.Add(Me.LinkLabel12)
        Me.Panel5.Controls.Add(Me.LinkLabel13)
        Me.Panel5.Controls.Add(Me.Button25)
        Me.Panel5.Controls.Add(Me.TextBox1)
        Me.Panel5.Controls.Add(Me.TextBox2)
        Me.Panel5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel5.Location = New System.Drawing.Point(6, 16)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(413, 54)
        Me.Panel5.TabIndex = 3
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.PictureBox3.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.PictureBox3.Location = New System.Drawing.Point(121, 37)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(13, 14)
        Me.PictureBox3.TabIndex = 35
        Me.PictureBox3.TabStop = False
        Me.PictureBox3.Visible = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.PictureBox4.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.PictureBox4.Location = New System.Drawing.Point(88, 9)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(13, 14)
        Me.PictureBox4.TabIndex = 34
        Me.PictureBox4.TabStop = False
        Me.PictureBox4.Visible = False
        '
        'Button24
        '
        Me.Button24.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button24.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button24.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button24.Location = New System.Drawing.Point(369, 28)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(33, 23)
        Me.Button24.TabIndex = 7
        Me.Button24.Text = "D"
        Me.Button24.UseVisualStyleBackColor = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(11, 37)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(13, 13)
        Me.Label19.TabIndex = 4
        Me.Label19.Text = "*"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(11, 9)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(13, 13)
        Me.Label20.TabIndex = 0
        Me.Label20.Text = "*"
        '
        'LinkLabel12
        '
        Me.LinkLabel12.AutoSize = True
        Me.LinkLabel12.Location = New System.Drawing.Point(22, 36)
        Me.LinkLabel12.Name = "LinkLabel12"
        Me.LinkLabel12.Size = New System.Drawing.Size(103, 13)
        Me.LinkLabel12.TabIndex = 5
        Me.LinkLabel12.TabStop = True
        Me.LinkLabel12.Text = "Issue Identification:"
        '
        'LinkLabel13
        '
        Me.LinkLabel13.AutoSize = True
        Me.LinkLabel13.Location = New System.Drawing.Point(21, 8)
        Me.LinkLabel13.Name = "LinkLabel13"
        Me.LinkLabel13.Size = New System.Drawing.Size(70, 13)
        Me.LinkLabel13.TabIndex = 1
        Me.LinkLabel13.TabStop = True
        Me.LinkLabel13.Text = "Series Name:"
        '
        'Button25
        '
        Me.Button25.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button25.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button25.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.Location = New System.Drawing.Point(369, 2)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(33, 23)
        Me.Button25.TabIndex = 3
        Me.Button25.Text = "D"
        Me.Button25.UseVisualStyleBackColor = False
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.Location = New System.Drawing.Point(140, 30)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(215, 21)
        Me.TextBox1.TabIndex = 6
        '
        'TextBox2
        '
        Me.TextBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox2.Location = New System.Drawing.Point(107, 4)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(248, 21)
        Me.TextBox2.TabIndex = 2
        '
        'Panel6
        '
        Me.Panel6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel6.Controls.Add(Me.TextBox3)
        Me.Panel6.Controls.Add(Me.Button26)
        Me.Panel6.Controls.Add(Me.PictureBox5)
        Me.Panel6.Controls.Add(Me.Label21)
        Me.Panel6.Controls.Add(Me.LinkLabel14)
        Me.Panel6.Location = New System.Drawing.Point(6, 330)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(422, 34)
        Me.Panel6.TabIndex = 51
        '
        'Button26
        '
        Me.Button26.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button26.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button26.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button26.Location = New System.Drawing.Point(378, 5)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(33, 23)
        Me.Button26.TabIndex = 49
        Me.Button26.Text = "D"
        Me.Button26.UseVisualStyleBackColor = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.PictureBox5.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.PictureBox5.Location = New System.Drawing.Point(131, 10)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(13, 14)
        Me.PictureBox5.TabIndex = 48
        Me.PictureBox5.TabStop = False
        Me.PictureBox5.Visible = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(5, 12)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(19, 13)
        Me.Label21.TabIndex = 27
        Me.Label21.Text = "**"
        '
        'LinkLabel14
        '
        Me.LinkLabel14.AutoSize = True
        Me.LinkLabel14.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel14.Location = New System.Drawing.Point(22, 10)
        Me.LinkLabel14.Name = "LinkLabel14"
        Me.LinkLabel14.Size = New System.Drawing.Size(114, 13)
        Me.LinkLabel14.TabIndex = 0
        Me.LinkLabel14.TabStop = True
        Me.LinkLabel14.Text = "Other Citation Details:"
        '
        'TextBox3
        '
        Me.TextBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox3.Location = New System.Drawing.Point(146, 7)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(215, 21)
        Me.TextBox3.TabIndex = 50
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.Controls.Add(Me._____warning)
        Me.GroupBox3.Controls.Add(Me.Panel28)
        Me.GroupBox3.Controls.Add(Me.Panel7)
        Me.GroupBox3.Controls.Add(Me.Panel29)
        Me.GroupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox3.Location = New System.Drawing.Point(3, 380)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(434, 40)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        '
        '_____warning
        '
        Me._____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me._____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me._____warning.Location = New System.Drawing.Point(418, 18)
        Me._____warning.Name = "_____warning"
        Me._____warning.Size = New System.Drawing.Size(13, 14)
        Me._____warning.TabIndex = 43
        Me._____warning.TabStop = False
        Me._____warning.Visible = False
        '
        'Panel28
        '
        Me.Panel28.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel28.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel28.Controls.Add(Me.Label42)
        Me.Panel28.Controls.Add(Me.Label82)
        Me.Panel28.Controls.Add(Me.Label28)
        Me.Panel28.Location = New System.Drawing.Point(6, 14)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(131, 20)
        Me.Panel28.TabIndex = 41
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label42.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Black
        Me.Label42.Location = New System.Drawing.Point(48, 3)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(13, 13)
        Me.Label42.TabIndex = 24
        Me.Label42.Text = "*"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(3, 3)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(47, 13)
        Me.Label82.TabIndex = 35
        Me.Label82.Text = "YELLOW"
        '
        'Label28
        '
        Me.Label28.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(63, 3)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(59, 13)
        Me.Label28.TabIndex = 34
        Me.Label28.Text = "mandatory"
        '
        'Panel7
        '
        Me.Panel7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel7.Controls.Add(Me.Label84)
        Me.Panel7.Controls.Add(Me.Label22)
        Me.Panel7.Location = New System.Drawing.Point(327, 14)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(86, 20)
        Me.Panel7.TabIndex = 40
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label84.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(3, 4)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(31, 13)
        Me.Label84.TabIndex = 34
        Me.Label84.Text = "BLUE"
        '
        'Label22
        '
        Me.Label22.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label22.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(40, 3)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(45, 13)
        Me.Label22.TabIndex = 32
        Me.Label22.Text = "optional"
        '
        'Panel29
        '
        Me.Panel29.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel29.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel29.Controls.Add(Me.Label85)
        Me.Panel29.Controls.Add(Me.Label83)
        Me.Panel29.Controls.Add(Me.Label23)
        Me.Panel29.Location = New System.Drawing.Point(143, 14)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(178, 20)
        Me.Panel29.TabIndex = 42
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label85.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.ForeColor = System.Drawing.Color.Black
        Me.Label85.Location = New System.Drawing.Point(42, 4)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(19, 13)
        Me.Label85.TabIndex = 36
        Me.Label85.Text = "**"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(3, 4)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(40, 13)
        Me.Label83.TabIndex = 30
        Me.Label83.Text = "GREEN"
        '
        'Label23
        '
        Me.Label23.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(58, 3)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(118, 13)
        Me.Label23.TabIndex = 29
        Me.Label23.Text = "mandatory if applicable"
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.Controls.Add(Me.Label26)
        Me.GroupBox4.Controls.Add(Me.btnCloseDiscard)
        Me.GroupBox4.Controls.Add(Me.btnCloseSave)
        Me.GroupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox4.Location = New System.Drawing.Point(443, 380)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(435, 40)
        Me.GroupBox4.TabIndex = 4
        Me.GroupBox4.TabStop = False
        '
        'btnCloseDiscard
        '
        Me.btnCloseDiscard.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCloseDiscard.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseDiscard.Location = New System.Drawing.Point(351, 9)
        Me.btnCloseDiscard.Name = "btnCloseDiscard"
        Me.btnCloseDiscard.Size = New System.Drawing.Size(78, 25)
        Me.btnCloseDiscard.TabIndex = 29
        Me.btnCloseDiscard.Text = "Cancel"
        Me.btnCloseDiscard.UseVisualStyleBackColor = True
        '
        'btnCloseSave
        '
        Me.btnCloseSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCloseSave.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseSave.Location = New System.Drawing.Point(253, 9)
        Me.btnCloseSave.Name = "btnCloseSave"
        Me.btnCloseSave.Size = New System.Drawing.Size(78, 25)
        Me.btnCloseSave.TabIndex = 28
        Me.btnCloseSave.Text = "Save && Close"
        Me.btnCloseSave.UseVisualStyleBackColor = True
        '
        'Panel8
        '
        Me.Panel8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel8.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel8.Controls.Add(Me.btnEdit_lworkcit)
        Me.Panel8.Controls.Add(Me.PictureBox6)
        Me.Panel8.Controls.Add(Me.Label24)
        Me.Panel8.Controls.Add(Me.LinkLabel15)
        Me.Panel8.Location = New System.Drawing.Point(6, 330)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(422, 34)
        Me.Panel8.TabIndex = 52
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.PictureBox6.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.PictureBox6.Location = New System.Drawing.Point(131, 10)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(13, 14)
        Me.PictureBox6.TabIndex = 48
        Me.PictureBox6.TabStop = False
        Me.PictureBox6.Visible = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(5, 12)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(19, 13)
        Me.Label24.TabIndex = 27
        Me.Label24.Text = "**"
        '
        'LinkLabel15
        '
        Me.LinkLabel15.AutoSize = True
        Me.LinkLabel15.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel15.Location = New System.Drawing.Point(22, 10)
        Me.LinkLabel15.Name = "LinkLabel15"
        Me.LinkLabel15.Size = New System.Drawing.Size(110, 13)
        Me.LinkLabel15.TabIndex = 0
        Me.LinkLabel15.TabStop = True
        Me.LinkLabel15.Text = "Larger Work Citation:"
        '
        'btnEdit_lworkcit
        '
        Me.btnEdit_lworkcit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEdit_lworkcit.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnEdit_lworkcit.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEdit_lworkcit.Location = New System.Drawing.Point(150, 5)
        Me.btnEdit_lworkcit.Name = "btnEdit_lworkcit"
        Me.btnEdit_lworkcit.Size = New System.Drawing.Size(43, 23)
        Me.btnEdit_lworkcit.TabIndex = 49
        Me.btnEdit_lworkcit.Text = "Edit"
        Me.btnEdit_lworkcit.UseVisualStyleBackColor = False
        '
        'Label26
        '
        Me.Label26.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(3, 9)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(110, 26)
        Me.Label26.TabIndex = 34
        Me.Label26.Text = "Click on text to link to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "  element description"
        '
        'CitationForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(880, 423)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CitationForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Source Citation"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        CType(Me.idinfo_citation_citeinfo_pubdate_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_citation_citeinfo_pubinfo_publish_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_citation_citeinfo_pubinfo_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.idinfo_citation_citeinfo_title_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_citation_citeinfo_origin_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        CType(Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        CType(Me._____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel29.ResumeLayout(False)
        Me.Panel29.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel3 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel4 As System.Windows.Forms.LinkLabel
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox6 As System.Windows.Forms.ComboBox
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel5 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel6 As System.Windows.Forms.LinkLabel
    Friend WithEvents ComboBox7 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox8 As System.Windows.Forms.ComboBox
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel7 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel8 As System.Windows.Forms.LinkLabel
    Friend WithEvents ComboBox9 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox10 As System.Windows.Forms.ComboBox
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel9 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel10 As System.Windows.Forms.LinkLabel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel22 As System.Windows.Forms.Panel
    Friend WithEvents idinfo_citation_citeinfo_pubdate_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_citation_citeinfo_pubinfo_pubplace_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents idinfo_citation_citeinfo_pubinfo_publish_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_citation_citeinfo_pubinfo_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_pubdate_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_pubdate_____today As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents idinfo_citation_citeinfo_pubdate As System.Windows.Forms.TextBox
    Friend WithEvents idinfo_citation_citeinfo_pubinfo_publish_____help As System.Windows.Forms.LinkLabel
    Public WithEvents idinfo_citation_citeinfo_pubinfo_publish As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_citation_citeinfo_pubinfo_pubplace As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_citation_citeinfo_pubinfo_pubplace_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents idinfo_citation_citeinfo_title_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_citation_citeinfo_origin_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_citation_citeinfo_title_____default As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents idinfo_citation_citeinfo_title_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_origin_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_origin_____default As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_title As System.Windows.Forms.TextBox
    Friend WithEvents idinfo_citation_citeinfo_origin As System.Windows.Forms.TextBox
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel14 As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel12 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel13 As System.Windows.Forms.LinkLabel
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents ComboBox11 As System.Windows.Forms.ComboBox
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel11 As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents dataqual_posacc_vertacc_qvertpa_vertaccv_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents dataqual_posacc_vertacc_qvertpa_vertaccv As System.Windows.Forms.TextBox
    Friend WithEvents dataqual_posacc_vertacc_qvertpa_vertaccv_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents _____warning As System.Windows.Forms.PictureBox
    Friend WithEvents Panel28 As System.Windows.Forms.Panel
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Panel29 As System.Windows.Forms.Panel
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnCloseDiscard As System.Windows.Forms.Button
    Friend WithEvents btnCloseSave As System.Windows.Forms.Button
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents btnEdit_lworkcit As System.Windows.Forms.Button
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel15 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label26 As System.Windows.Forms.Label
End Class
